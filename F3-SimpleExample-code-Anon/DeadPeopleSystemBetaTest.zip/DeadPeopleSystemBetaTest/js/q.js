$(document).ready(function() {
    $("#btn3").click(function() {
        $("#login").css("display", "none");
        $("#login2").css("display", "block");
    })
})

$(document).ready(function() {
    $("#btn4").click(function() {
        $("#login").css("display", "block");
        $("#login2").css("display", "none");
    })
})